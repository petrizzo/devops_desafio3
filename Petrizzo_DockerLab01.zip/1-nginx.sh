#!/bin/bash

echo "Descargando Docker de nginx"
sudo docker pull nginx
echo "fin"